#include <iostream>
#include <fstream>
using namespace std;
int main(){
    ifstream in("input.txt");
    ofstream out("output.txt");

    int id, basic;
    
    out << "ID\tBASIC Salary\n";

    while(in >> id >> basic){
        float bra = 0.2 * basic;
        float da = 0.1 * basic;
        basic = basic + bra + da;
        out<<id<<"\t"<<basic<<endl;
    }

    in.close();
    out.close();
    cout<<"Successfully Executed!"<<endl;
    return 0;
}